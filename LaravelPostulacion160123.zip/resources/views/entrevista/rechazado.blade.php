
 @extends('layouts.head')

 @section('content')

 <div class="card br-16 pt-56 pb-56">
   <div class="card-body">
Rechazaaaaadasoo
   </div>
</div>

 @endsection


