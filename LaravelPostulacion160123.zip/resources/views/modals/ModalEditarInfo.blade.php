<!-- BEGIN: Modal Content -->
<div id="modeleditar{{$info->id}}" class="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body p-10 text-center"> This is totally awesome blank modal! </div>
        </div>
    </div>
</div> <!-- END: Modal Content -->
