
 @extends('layouts.head')


 @section('content')

<div class="card br-16 pt-56">
    <div class="card-body pb-0">

         <div class="box p-8 relative overflow-hidden m-auto   w-100 w-lg-50 text-center">

            <div class="text-pri font-16 text-center mt-24">
                <h1 class="font-weight-bold text-pri">Gracias por finalizar<br>
                    la etapa de postulación</h1>
                    <p>
                        Nos pondremos en contacto con usted , para indicarle<br>
                        las proximas acciones a realizar.
                    </p>

                    <img src="{{asset('app-assets/images/konecta/personas-saludando.png')}}" width="100%">

            </div>
        </div>
    </div>
</div>
<div class="col-span-12  mt-6 text-center ">

</div>

 @endsection


