
 


 <?php $__env->startSection('content'); ?>


 <div class="card br-16 p-36">


        <div class="card-body">


            <div class="row m-0">
                <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($documento)): ?>
                            <?php $__currentLoopData = $documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-4">
                                <a type="button" href="<?php echo e(route('documentos.index',$doc->id_user)); ?>"
                                class="btn btn-outline-primary round waves-effect">Atras</a>
                            </div>
                            Se convirtio exitosamente
                            <?php echo e($doc->ruta); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                    <h2 class="intro-y text-lg font-medium mr-auto font-weight-bold">
                        AUTORIZACIÓN DE ACCESO A EQUIPOS PROPIOS
                    </h2>

                    <form action="<?php echo e(route('pdf.getGenerar6')); ?>" method="post"  enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="descargar" name="accion">
                            <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="id_user">

                            <div class="col-lg-4 mt-8">
                                <label class="form-label" for="first-name-icon">Lugar</label>
                                                                                <div class="input-group input-group-merge">
                                                                                    <input type="text" id="lugar" class="form-control" name="lugar" placeholder="Lugar" required>
                                                                                </div>
                            </div>

                            <div class="col-lg-4 mt-8">
                                <label class="form-label" for="first-name-icon">Fecha</label>
                                                                                <div class="input-group input-group-merge">
                                                                                    <input type="date" id="fecha" class="form-control" name="fecha"required >
                                                                                </div>
                            </div>

                            <div class="col-lg-12 mt-24">
                                Yo,	<b><?php echo e($item->nombres); ?> <?php echo e($item->apellido_pa); ?> <?php echo e($item->apellido_ma); ?></b>  identificado con DNI N°  <b><?php echo e($item->numero_documento); ?></b> con domicilio <b><?php echo e($item->direccion); ?></b> .Distrito <b><?php echo e($item->distrito); ?></b>,
                                Provincia de <b><?php echo e($item->provincia); ?></b> y departamento de <b><?php echo e($item->departamento); ?></b>; mediante el presente documento declaro lo siguiente:<br><br>

                                Que autorizo a Konecta Perú1 para que acceda a los equipos de mi propiedad, con la finalidad de realizar acciones tendientes al inicio de mis labores y durante la prestación de servicios; en base a las cuales se realizarán:<br><br>
                                <ol>
                                    <li>Las configuraciones para la activación de usuarios, permisos y restricciones para la seguridad de la información.</li>
                                    <li>Las configuraciones para el remoteo del equipo.</li>
                                    <li>Las revisiones para verificar el cumplimiento normativo a través de auditorías.</li>
                                </ol>

                                Asimismo, declaro que el consentimiento brindado es libre, expreso e informado previamente; por lo que no ha existido ningún tipo de coacción para el ejercicio del mismo.<br><br>


                                Firmo al pie del presente documento en señal de conformidad.

                            </div>



                            <div class="col-lg-12 mt-24">


                                <div class="col-lg-4 mt-24">
                                    <h3>Firma</h3>
                                    <input type="file" id="select-files" name="firma" class="btn btn-outline-primary mb-1 waves-effect dz-clickable" required>
                                </div>
                                <p><b><?php echo e($item->nombres); ?> <?php echo e($item->apellido_pa); ?> <?php echo e($item->apellido_ma); ?> </b>  </p>
                                <p><b>DNI:</b> <?php echo e($item->numero_documento); ?></p>


                                <hr>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">
                                        ENVIAR DOCUMENTO
                                    </button>
                                </div>

                            </div>
                    </form>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

           


        </div>


</div>


 <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/documentos/doc6.blade.php ENDPATH**/ ?>