
 

 <?php $__env->startSection('content'); ?>

 <div class="card br-16 pt-56 pb-56">
   <div class="card-body">
Rechazaaaaadasoo
   </div>
</div>

 <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/entrevista/rechazado.blade.php ENDPATH**/ ?>