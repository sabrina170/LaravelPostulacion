<!doctype html>
 <html lang="en">
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title>Bootstrap demo</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

     <style>
      body{
        font-family: arial;
      }
     </style>

    </head>
   <body style="font-family: arial">


     <div style="margin-top: 10px;">
        <img src="<?php echo e(asset('app-assets/images/logo.jpg')); ?>" width="15%">
    </div>
    <div>
        <h4 class="text-center mt-4" style="font-size:14px"><strong>FICHA DE DATOS DEL TRABAJADOR <br>
            <span><?php echo e($fecha); ?></span></strong></h4>
    </div>

        <h4 style="font-size:16px; font-weight:bold; font-family:arial;">1.	DATOS DEL TRABAJADOR</h4>


        <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-lg-12">
            <table class="table table-bordered">
              <tr>
                <td>Nombres:</td>
                <td><?php echo e($item->nombres); ?></td>
              </tr>
              <tr>
                <td>Apellidos:</td>
                <td><?php echo e($item->apellido_pa); ?> <?php echo e($item->apellido_ma); ?></td>
              </tr>
              <tr>
                <td>Fecha de nacimiento:</td>
                <td><?php echo e($item->fecha_nacimiento); ?></td>
              </tr>
              <tr>
                <td>Lugar de nacimiento:</td>
                <td><?php echo e($lugar_nacimiento); ?></td>
              </tr>
              <tr>
                <td>Edad:</td>
                <td><?php echo e($edad); ?></td>
              </tr>
              <tr>
                <td>Estado Civil:</td>
                <td><?php echo e($estado_civil); ?></td>
              </tr>
              <tr>
                <td>Nacionalidad:</td>
                <td><?php echo e($nacionalidad); ?></td>
              </tr>
              <tr>
                <td>DNI:</td>
                <td><?php echo e($item->numero_documento); ?></td>
              </tr>
              <tr>
                <td>Domicilio:</td>
                <td><?php echo e($item->direccion); ?></td>
              </tr>
              <tr>
                <td>Distrito:</td>
                <td><?php echo e($item->distrito); ?></td>
              </tr>
              <tr>
                <td>Provincia:</td>
                <td><?php echo e($item->provincia); ?></td>
              </tr>
              <tr>
                <td>Departamento:</td>
                <td><?php echo e($item->departamento); ?></td>
              </tr>
              <tr>
                <td colspan="2"><img src="/images-croquis/<?php echo e($croquis); ?>" class="img-fluid mt-4" alt="..."></td>
              </tr>
            </table>

            <table>
              <tr>
                <td>Teléfono Fijo:</td>
                <td><?php echo e($telefono_fijo); ?></td>
                <td>Teléfono Móvil:</td>
                <td><?php echo e($telefono); ?></td>
              </tr>
              <tr>
                <td>Teléfono de Contacto:</td>
                <td><?php echo e($telefono_familiar); ?></td>
                <td>Referencia:</td>
                <td><?php echo e($referencia); ?></td>
              </tr>
            </table>

          <h4>Nivel Educativo</h4>
          <p><?php echo e($nivel_educativo); ?></p>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h4 class="mt-36">2.	DATOS DE FAMILIARES DIRECTOS (padre, madre, cónyuge o conviviente e hijos):</h4>

        <table class="table table-bordered">
          <thead>
            <tr class="table-active">
                          <th>Nombres y Apellidos Completos</th>
                            <th>Parentesco</th>
                            <th>Edad</th>
                            <th>Sexo</th>
                            <th>Tipo doc</th>
                            <th>Nro doc</th>
                            <th>Estudia</th>
            </tr>
          </thead>
          <tbody>

              <?php for($i=0; $i<count($datos_nombres); $i++): ?>
                  
            <tr>
              <td><?php echo e($datos_nombres[$i]); ?></td>
              <td><?php echo e($datos_parentesco[$i]); ?></td>
              <td><?php echo e($datos_edad[$i]); ?></td>
              <td><?php echo e($datos_sexo[$i]); ?></td>
              <td><?php echo e($datos_tipo_dni[$i]); ?></td>
              <td><?php echo e($datos_numero_dni[$i]); ?></td>
              <td><?php echo e($datos_estudia[$i]); ?></td>
            </tr>
            <?php endfor; ?>
          </tbody>
        </table>

        <p class="font-11 mt-12">(En caso de hijos mayores de 18 años, indicar si éstos cursan estudios superiores o universitarios. La empresa se reserva el derecho de exigir al trabajador que acredite la existencia de los hijos.)</p>

        <h4 class="mt-36">DATOS LABORALES</h4>
        <h5>3.1.	Renta Quinta  </h5>

            <div>
                <p class="form-label" for="first-name-icon">
                    <strong>Ha trabajado anteriormente este año?:
                        </strong><?php echo e($trabajo); ?></p>
            </div>
            <div>
                <p class="form-label" for="first-name-icon">
                    <strong>Nombre del empleador:</strong>
                    <?php echo e($nombre_empleador); ?></p>

            </div>
            <div>
                <p class="form-label" for="first-name-icon">
                    <strong>Domiciliado:</strong>
                    <?php echo e($domiciliado); ?></p>
            </div>
            <div>
                <p class="form-label" for="first-name-icon">
                    <strong>Fecha de cese de su último empleo:
                        </strong><?php echo e($fecha_cese); ?></p>
            </div>
          <h5>3.2.	Essalud Vida </h5>

            <div>
                <p class="form-label" for="first-name-icon">
                    <strong>Indicar si está afiliado a Essalud Vida:
                        </strong><?php echo e($afiliado); ?></p>
            </div>
            <div>
                <p class="form-label" for="first-name-icon">
                    <strong>Si es extranjero indicar días de permanencia en el país
                        </strong><?php echo e($dias_per); ?></p>
            </div>
            <h4 class="font-weight-bold">Consideraciones para presentar Descanso Médico</h4>
            <p class="mt-24">
              Según nuestro Reglamento de Seguridad y Salud en el Trabajo (RISS Art. 109 Ind. C), todo Descanso Médico Particular debe contener:
              <ul>
                  <li>Pago de la consulta médica</li>
                  <li>Certificado Médico, indicando datos del personal y días de Descanso Médic</li>
                  <li>Receta</li>
                  <li>Compra de la Receta</li>
              </ul>
          </p>

          <p>
              El Descanso Médico debe ser presentado máximo a las 72 hrs de haberse producido el hecho, de presentarse fuera de fecha y/o incompletos, la empresa no asumirá compensación salarial por los días no trabajados, ya que es responsabilidad única y exclusiva del colaborador.<br>
              Ante caso de SUBSIDIOS (más de 20 días de Descanso Médico) se podrá requerir documentos adicionales que sustenten el diagnóstico, en caso de no presentarlos e impidan cualquier tipo de trámite posterior de subsidios en las fechas correspondientes, la empresa no asumirá compensación salarial por los días subsidiados.<br>
              Adicionalmente, se consigna como Falta Grave sí el Descanso Médico presentado sea Fraudulento o se haya comprobado su comercialización.

          </p>

          <h4 class="font-weight-bold">Compensación por Tiempo de Servicios (CTS)</h4>
                <p>Moneda: SOLES</p>

                <h4 class="font-weight-bold">Pago de haberes</h4>
                <p>Modalidad de pago: MENSUAL</p>

                <h4 class="font-weight-bold">Exclusividad</h4>
                <p><?php echo e($exclusividad); ?></p>

        <img src="/images-firma/<?php echo e($firma); ?>" class="img-thumbnail mt-24" alt="...">


     </div>

     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
   </body>
 </html>



<?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/documentos/pdf_doc1.blade.php ENDPATH**/ ?>