
 


 <?php $__env->startSection('content'); ?>

 <div class="card br-16">
    <div class="meetup-img-wrapper rounded-top text-center">
        <img class="card-img-top br-16" src="<?php echo e(asset('app-assets/images/portada2.jpg')); ?>" alt="Card image cap" style="object-fit:cover;" height="270">
    </div>
</div>

<div class="card br-16 p-36">
    <div class="card-body">
        <h2 class="intro-y text-lg font-medium mr-auto font-weight-bold">
            MIS DOCUMENTOS
        </h2>
        <h5 class="intro-y mr-auto">
            Por favor, llene todos los documentos a continuación, luego darle click a enviar para proceder con la postulación:
        </h5>
        <div class="table-responsive">
            <table class="table  table-bordered mt-24">
                <thead>
                    <tr>
                        <th>DOCUMENTO</th>
                        <th>SUBIR ARCHIVO</th>
                        <th>ARCHIVOS SUBIDOS</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-pri font-weight-bold">CERTIFICADO DE ESTUDIOS</td>
                        <td>
                            <?php if(count($certificado) > 0): ?>
                            <span class="badge bg-success">Listo</span>
                            <?php else: ?>

                                <form action="<?php echo e(route('subirarchivos')); ?>" method="post" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <label for="formFile" class="form-label">Selecciona varios archivos</label>
                                    <input class="form-control"  type="file" name="images[]" multiple  required>
                                    <input type="hidden" value="1" name="tipo">
                                    <input type="hidden" value="Certificado" name="nombre">

                                </div>

                                <div class="col-lg-6 col-md-12 mt-12">
                                    <button type="submit" class="btn btn-dark waves-effect waves-float waves-light">Subir documentos</button>
                                </div>
                            </div>
                                </form>

                            <?php endif; ?>

                        </td>
                        <td>
                            <?php if(count($certificado) > 0): ?>
                                <?php $__currentLoopData = $certificado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <ul class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cer->id==$d->docpos_id): ?>
                                            <li class="list-group-item">
                                                <span><?php echo e($d->image); ?></span>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Ningun documento
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-pri font-weight-bold">CONSTANCIAS DE TRABAJOS</td>
                        <td>
                            <?php if(count($constancia) > 0): ?>
                            <span class="badge bg-success">Listo</span>
                            <?php else: ?>
                            <form action="<?php echo e(route('subirarchivos')); ?>" method="post" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12">
                                        <label for="formFile" class="form-label">Selecciona varios archivos</label>
                                        <input class="form-control"  type="file" name="images[]" multiple  required>
                                        <input type="hidden" value="2" name="tipo">
                                        <input type="hidden" value="Constancia" name="nombre">
                                    </div>
                                    <div class="col-lg-6 col-md-12 mt-12">
                                        <button type="submit" class="btn btn-dark waves-effect waves-float waves-light">Subir documentos</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>

                        </td>
                        <td>
                            <?php if(count($constancia) > 0): ?>
                                <?php $__currentLoopData = $constancia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <ul class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cer->id==$d->docpos_id): ?>
                                            <li class="list-group-item">
                                                <span><?php echo e($d->image); ?></span>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Ningun documento
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-pri font-weight-bold">ANTECEDENTES</td>
                        <td>
                            <?php if(count($antecedente) > 0): ?>
                            <span class="badge bg-success">Listo</span>
                            <?php else: ?>
                            <form action="<?php echo e(route('subirarchivos')); ?>" method="post" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12">
                                        <label for="formFile" class="form-label">Selecciona varios archivos</label>
                                        <input class="form-control"  type="file" name="images[]" multiple  required>
                                        <input type="hidden" value="3" name="tipo">
                                        <input type="hidden" value="Antecedentes" name="nombre">
                                    </div>
                                    <div class="col-lg-6 col-md-12 mt-12">
                                        <button type="submit" class="btn btn-dark waves-effect waves-float waves-light">Subir documentos</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>

                        </td>
                        <td>
                            <?php if(count($antecedente) > 0): ?>
                                <?php $__currentLoopData = $antecedente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <ul class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cer->id==$d->docpos_id): ?>
                                            <li class="list-group-item">
                                                <span><?php echo e($d->image); ?></span>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Ningun documento
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-pri font-weight-bold">DNI</td>
                        <td>
                            <?php if(count($dni) > 0): ?>
                            <span class="badge bg-success">Listo</span>
                            <?php else: ?>
                            <form action="<?php echo e(route('subirarchivos')); ?>" method="post" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12">
                                        <label for="formFile" class="form-label">Selecciona varios archivos</label>
                                        <input class="form-control"  type="file" name="images[]" multiple  required>
                                        <input type="hidden" value="4" name="tipo">
                                        <input type="hidden" value="Dni" name="nombre">
                                    </div>
                                    <div class="col-lg-6 col-md-12 mt-12">
                                        <button type="submit" class="btn btn-dark waves-effect waves-float waves-light">Subir documentos</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>

                        </td>
                        <td>
                            <?php if(count($dni) > 0): ?>
                                <?php $__currentLoopData = $dni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <ul class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cer->id==$d->docpos_id): ?>
                                            <li class="list-group-item">
                                                <span><?php echo e($d->image); ?></span>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Ningun documento
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-pri font-weight-bold">CERTIFICACIÓN DE RENTA 5TA CATEGORÍA</td>
                        <td>
                            <?php if(count($renta) > 0): ?>
                            <span class="badge bg-success">Listo</span>
                            <?php else: ?>
                            <form action="<?php echo e(route('subirarchivos')); ?>" method="post" enctype="multipart/form-data" >
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12">
                                        <label for="formFile" class="form-label">Selecciona varios archivos</label>
                                        <input class="form-control"  type="file" name="images[]" multiple  required>
                                        <input type="hidden" value="5" name="tipo">
                                        <input type="hidden" value="Renta" name="nombre">
                                    </div>
                                    <div class="col-lg-6 col-md-12 mt-12">
                                        <button type="submit" class="btn btn-dark waves-effect waves-float waves-light">Subir documentos</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>

                        </td>
                        <td>
                            <?php if(count($renta) > 0): ?>
                                <?php $__currentLoopData = $renta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <ul class="list-group list-group-numbered">
                                    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cer->id==$d->docpos_id): ?>
                                            <li class="list-group-item">
                                                <span><?php echo e($d->image); ?></span>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Ningun documento
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="text-center">
            <div id="alerta">

            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="confirmo" value="checked">
                <label class="form-check-label" for="inlineCheckbox1">Confirmo haber completado todos los documentos para la respectiva postulación</label>
            </div>
            <br>
            <input type="hidden" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <button id="boton1" onclick="boton2"  class="col-lg-4 mt-4 btn btn-primary waves-effect waves-float waves-light">Enviar documentos</button>
        </div>

    </div>
                </div>

 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('js'); ?>

 <script>


      document.getElementById('boton1').onclick = function(){

         var query = $('#user_id').val();
         if ($('#confirmo').prop('checked') ) {
                 $.ajax({
                     url:'<?php echo e(route('cambiarestadopos2')); ?>',
                     type:'GET',
                     data:{'id_user':query},
                     dataType:'json',
                     success:function (data) {
                         location.href="<?php echo e(route('finalizado')); ?>";
                     }
                 })
         }else{

             $('#alerta').html('<div class="alert alert-warning" role="alert"><div class="alert-body"><strong>Selecciona el check de confirmacíon</strong></div></div>')
         }
 }



 </script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/documentos/docs.blade.php ENDPATH**/ ?>