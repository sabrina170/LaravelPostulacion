
 


 <?php $__env->startSection('content'); ?>


 <div class="card br-16 p-36">


        <div class="card-body">


            <div class="row m-0">
                <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($documento)): ?>
                            <?php $__currentLoopData = $documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-4">
                                <a type="button" href="<?php echo e(route('documentos.index',$doc->id_user)); ?>"
                                class="btn btn-outline-primary round waves-effect">Atras</a>
                            </div>
                            Se convirtio exitosamente
                            <?php echo e($doc->ruta); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                    <h2 class="intro-y text-lg font-medium mr-auto font-weight-bold">
                        DECLARACIÓN JURADA DE DATOS Y DOMICILIO LEGAL
                    </h2>
                    <p>Fecha: <?php echo date("d-m-y");?></p>



                    <p>El que suscribe <b><?php echo e($item->apellido_pa); ?> <?php echo e($item->apellido_ma); ?>  <?php echo e($item->nombres); ?></b> N° DNI  <b><?php echo e($item->numero_documento); ?></b> con domicilio actual en (Av./Clle./Mz./Lt. – Int/Dpto) <b><?php echo e($item->direccion); ?></b> Distrito: <b><?php echo e($item->distrito); ?></b> Provincia: <b><?php echo e($item->provincia); ?></b> <br> Teléfono: <b><?php echo e($item->telefono); ?></b> </p>

                    <p>Referencias adicionales: </p>

                    <p>Declaro dicho domicilio como actual y legal ante cualquier notificación o control de la Empresa, comprometiéndome  a comunicar fehacientemente dentro de las cuarenta y ocho horas, su cambio o modificación.</p>

                    <form action="<?php echo e(route('pdf.getGenerar2')); ?>" method="post"  enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="descargar" name="accion">
                            <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="id_user">

                            <div class="col-lg-4 mt-8">
                                <!--<label class="form-label" for="first-name-icon">Lugar</label>-->
                                                                                <div class="input-group input-group-merge">
                                                                                    <input type="hidden" id="first-name-icon" class="form-control" name="lugar" placeholder="Lugar" required>
                                                                                </div>
                            </div>

                            <div class="col-lg-4 mt-8">
                                <!--<label class="form-label" for="first-name-icon">Fecha</label>-->
                                                                                <div class="input-group input-group-merge">
                                                                                    <input type="hidden" id="first-name-icon" class="form-control" name="fecha"required >
                                                                                </div>
                            </div>



                            <div class="col-lg-4 mt-24">
                                <!--<h3>Adjuntar croquis</h3>-->
                                <input type="hidden" id="select-files" name="croquis" class="btn btn-outline-primary mb-1 waves-effect dz-clickable" required>
                            </div>

                            <div class="col-lg-12 mt-24">
                                <h3>Firma</h3>
                <input type="file" id="firma" name="firma"
                class="btn btn-outline-primary mb-1 waves-effect dz-clickable" required>
                <hr>

                                <p><b><?php echo e($item->nombres); ?> <?php echo e($item->apellido_pa); ?> <?php echo e($item->apellido_ma); ?></b></p>
                                <p><b>DNI:</b> <?php echo e($item->numero_documento); ?></p>


                                <hr>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary waves-effect waves-float waves-light">
                                        ENVIAR DOCUMENTO
                                    </button>
                                </div>

                            </div>
                    </form>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

           


        </div>


</div>


 <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/documentos/doc2.blade.php ENDPATH**/ ?>