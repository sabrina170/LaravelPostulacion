<!DOCTYPE html>
<html>
<head>
 <title>BOLETA DE VENTA</title>
 <style type="text/css">
 body{
 font-size: 16px;
 font-family: "Arial";
 }
 table{
 border-collapse: collapse;
 }
 td{
 padding: 6px 5px;
 font-size: 15px;
 }
 .h1{
 font-size: 21px;
 font-weight: bold;
 color: blue;
 }
 .h2{
 font-size: 18px;
 font-weight: bold;
 }
</style>


</head>
<body>
 <div >

    <div>

    </div>
 <div class="card br-16 p-36">


    <div class="card-body">

        <label class="form-label" for="first-name-icon">Lugar</label>
        <?php echo e($lugar); ?>

        <br>
        <label class="form-label" for="first-name-icon">Fecha</label>
        <?php echo e($fecha); ?>


    <div class="row m-0">
        <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <h1 class="h1">
            DOCUMENTO 6
        </h1>
        <h5 class="intro-y mr-auto">
            

       </h5>
       <p><b><?php echo e($item->apellido_pa); ?> <?php echo e($item->apellido_ma); ?>  <?php echo e($item->nombres); ?> </b></p>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <h1>Fima</h1>
       <img src="/images-firma/<?php echo e($firma); ?>" alt="">
       
 </div>

 
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/documentos/pdf_doc6.blade.php ENDPATH**/ ?>