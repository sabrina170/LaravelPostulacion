
<!-- MENU -->
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">

        <h2 class="text-pri font-weight-bold">Editar postulante <strong>Sabrina</strong></h2>
        
            <?php $__currentLoopData = $info_postulante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- left profile info section -->
            <div class="row">
            <div class="col-lg-4 col-12 order-2 order-lg-1">
                <!-- about -->

                <div class="card">
                    <div class="card-body">



                        <h5 class="mb-75 font-weight-bold">INFORMACIÓN PERSONAL</h5>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Nombres y Apellidos                                :</h5>
                            <p class="card-text"><?php echo e($item->nombres); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Dni:</h5>
                            <p class="card-text"><?php echo e($item->numero_documento); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Email:</h5>
                            <p class="card-text"><?php echo e($item->correo); ?></p>
                        </div>

                        <div class="mt-2">
                            <form method="POST" action="<?php echo e(route('admin.actualizar',$item->id)); ?>">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <h5 class="mb-50 font-weight-bold">Estado:</h5>
                                <select class="form-select" id="basicSelect" name="estado">
                                    
                                    
                                    <option value="4" <?php if($item->estado == 4): ?> selected <?php endif; ?>>Aceptado</option>
                                    
                                    <option value="7" <?php if($item->estado == 7): ?> selected <?php endif; ?>>Rechazado</option>
                                    <option value="5" <?php if($item->estado == 5): ?> selected <?php endif; ?>>Enviar Documentos</option>
                                    <option value="6" <?php if($item->estado == 6): ?> selected <?php endif; ?>>Legajo Documentos</option>

                                </select>
                                <input type="submit" class="btn btn-success" value="Actualizar estado">
                            </form>
                        </div>
                    </div>
                </div>
                <!--/ about -->

            </div>
            <!--/ left profile info section -->

            <!-- center profile info section -->
            <div class="col-lg-4 col-12 order-1 order-lg-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="mb-75">ESTUDIOS</h5>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Grado de formación:</h5>
                            <p class="card-text"><?php echo e($item->grado); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Nombre de institución educativa:</h5>
                            <p class="card-text"><?php echo e($item->nombre_ie); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Estudia actualmente?:</h5>
                            <p class="card-text"><?php echo e($item->estudia); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-50 font-weight-bold">Horario de estudios:</h5>
                            <p class="card-text mb-0"><?php echo e($item->horario); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Disponibilidad</h5>
                            <p class="card-text"><?php echo e($item->disponibilidad); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!--/ center profile info section -->

            <!-- right profile info section -->
            <div class="col-lg-4 col-12 order-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="mb-75">EXPERIENCIA LABORAL</h5>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">¿Has laborado en call center?:</h5>
                            <p class="card-text"><?php echo e($item->callcenter); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Nombre de empresa:</h5>
                            <p class="card-text"><?php echo e($item->empresa); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-75 font-weight-bold">Puesto experiencia:</h5>
                            <p class="card-text"><?php echo e($item->puesto); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-50 font-weight-bold">Tiempo (meses):</h5>
                            <p class="card-text mb-0"><?php echo e($item->tiempo); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-50 font-weight-bold">Tipo experiencia:</h5>
                            <p class="card-text mb-0"><?php echo e($item->tipo_expe); ?></p>
                        </div>
                        <div class="mt-2">
                            <h5 class="mb-50 font-weight-bold">Trabajó en Konecta:</h5>
                            <p class="card-text mb-0"><?php echo e($item->konecta); ?></p>
                        </div>
                    </div>
                </div>
             </div>
            </div>
            <div class="row">
             <div class="col-lg-12 col-12 order-1 order-lg-2">
                <div class="card">
                    <div class="card-body">
                        <h5 class="mb-75">Datos de la PC</h5>

                        
                        <ul class="list-group">
                            <?php $__currentLoopData = json_decode($item->datos_pc); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item2==1): ?>
                            <li class="list-group-item">Auriculares Normal</li>
                            <?php elseif($item2==2): ?>
                            <li class="list-group-item">Auriculares tipo Vincha</li>
                            <?php else: ?>
                            <li class="list-group-item"><?php echo e($item2); ?></li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                           
                            
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<!-- BEGIN: Page JS-->
<script src="<?php echo e(asset('app-assets/js/scripts/charts/chart-chartjs.js')); ?>"></script>
<!-- END: Page JS-->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adm-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/admin/editar-pos.blade.php ENDPATH**/ ?>