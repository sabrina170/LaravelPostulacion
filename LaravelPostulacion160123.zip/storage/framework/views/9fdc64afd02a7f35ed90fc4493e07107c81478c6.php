
 


 <?php $__env->startSection('content'); ?>

 <div class="card br-16">
    <div class="meetup-img-wrapper rounded-top text-center">
        <img class="card-img-top br-16" src="<?php echo e(asset('app-assets/images/portada2.jpg')); ?>" alt="Card image cap" style="object-fit:cover;" height="270">
    </div>
</div>

<div class="card br-16 p-36">
    <div class="card-body">
        <h2 class="intro-y text-lg font-medium mr-auto">
            LLENADO DE DOCUMENTOS
        </h2>
        <h5 class="intro-y mr-auto">
            Por favor, llene todos los documentos a continuación, luego darle click a enviar para proceder con la postulación:
        </h5>

        <div class="border br-16 row pt-12 pb-12 pl-0 pr-0 m-0 mt-24">
            <p class="col-lg-2 mb-0 text-center"><i data-feather='file'></i></p>
            <p class="col-lg-4 mb-0">Ficha del trabajador</p>
            <?php if(isset($docs)): ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->tipo==1): ?>
                        <?php if($d->estado==1): ?>
                        <p class="col-lg-4 mb-0"><span class="badge bg-info">Completado</span></p>
                        <?php else: ?>
                        <p class="col-lg-4 mb-0">Pendiente</p>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="col-lg-4 mb-0">Pendiente</p>
            <?php endif; ?>

            <p class="col-lg-2 mb-0 text-center">
                <a href="<?php echo e(route('doc1',[Auth::user()->id,1])); ?>"><i data-feather='arrow-right'></i></a></p>
        </div>


        <div class="border br-16 row pt-12 pb-12 pl-0 pr-0 m-0 mt-8">
            <p class="col-lg-2 mb-0 text-center"><i data-feather='file'></i></p>
            <p class="col-lg-4 mb-0">Declaración jurada de datos y domicilio legal</p>
            <?php if(isset($docs)): ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->tipo==2): ?>
                        <?php if($d->estado==1): ?>
                        <p class="col-lg-4 mb-0"><span class="badge bg-info">Completado</span></p>
                        <?php else: ?>
                        <p class="col-lg-4 mb-0">Pendiente</p>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="col-lg-4 mb-0">Pendiente</p>
            <?php endif; ?>
             <p class="col-lg-2 mb-0 text-center"><a href="<?php echo e(route('doc2',[Auth::user()->id,2])); ?>"><i data-feather='arrow-right'></i></a></p>

        </div>

        <div class="border br-16 row pt-12 pb-12 pl-0 pr-0 m-0 mt-8">
            <p class="col-lg-2 mb-0 text-center"><i data-feather='file'></i></p>
            <p class="col-lg-4 mb-0">Declaración Jurada</p>
            <?php if(isset($docs)): ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->tipo==3): ?>
                        <?php if($d->estado==1): ?>
                        <p class="col-lg-4 mb-0"><span class="badge bg-info">Completado</span></p>
                        <?php else: ?>
                        <p class="col-lg-4 mb-0">Pendiente</p>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="col-lg-4 mb-0">Pendiente</p>
            <?php endif; ?>
            <p class="col-lg-2 mb-0 text-center"><a href="<?php echo e(route('doc3',[Auth::user()->id,3])); ?>"><i data-feather='arrow-right'></i></a></p>
        </div>

        <div class="border br-16 row pt-12 pb-12 pl-0 pr-0 m-0 mt-8">
            <p class="col-lg-2 mb-0 text-center"><i data-feather='file'></i></p>
            <p class="col-lg-4 mb-0">Declaración juarada para el sistema previsional de pensión</p>
            <?php if(isset($docs)): ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->tipo==4): ?>
                        <?php if($d->estado==1): ?>
                        <p class="col-lg-4 mb-0"><span class="badge bg-info">Completado</span></p>
                        <?php else: ?>
                        <p class="col-lg-4 mb-0">Pendiente</p>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="col-lg-4 mb-0">Pendiente</p>
            <?php endif; ?>
            <p class="col-lg-2 mb-0 text-center"><a href="<?php echo e(route('doc4',[Auth::user()->id,4])); ?>"><i data-feather='arrow-right'></i></a></p>
        </div>

        <div class="border br-16 row pt-12 pb-12 pl-0 pr-0 m-0 mt-8">
            <p class="col-lg-2 mb-0 text-center"><i data-feather='file'></i></p>
            <p class="col-lg-4 mb-0">Compromiso de NO suplantación de identidad</p>
            <?php if(isset($docs)): ?>
            <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($d->tipo==5): ?>
                    <?php if($d->estado==1): ?>
                    <p class="col-lg-4 mb-0"><span class="badge bg-info">Completado</span></p>
                    <?php else: ?>
                    <p class="col-lg-4 mb-0">Pendiente</p>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <p class="col-lg-4 mb-0">Pendiente</p>
        <?php endif; ?>
            <p class="col-lg-2 mb-0 text-center"><a href="<?php echo e(route('doc5',[Auth::user()->id,5])); ?>"><i data-feather='arrow-right'></i></a></p>
        </div>
        <div class="border br-16 row pt-12 pb-12 pl-0 pr-0 m-0 mt-8">
            <p class="col-lg-2 mb-0 text-center"><i data-feather='file'></i></p>
            <p class="col-lg-4 mb-0">Autorización de acceso a equipos propios</p>
            <?php if(isset($docs)): ?>
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->tipo==6): ?>
                        <?php if($d->estado==1): ?>
                        <p class="col-lg-4 mb-0"><span class="badge bg-info">Completado</span></p>
                        <?php else: ?>
                        <p class="col-lg-4 mb-0">Pendiente</p>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="col-lg-4 mb-0">Pendiente</p>
            <?php endif; ?>
            <p class="col-lg-2 mb-0 text-center"><a href="<?php echo e(route('doc6',[Auth::user()->id,6])); ?>"><i data-feather='arrow-right'></i></a></p>
        </div>
    </div>

    <?php if(isset($docs)): ?>
        <?php if($docs_num == 6): ?>
        <div class="text-center">
            <div id="alerta">

            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="confirmo" value="checked">
                <label class="form-check-label" for="inlineCheckbox1">Confirmo haber completado todos los documentos para la respectiva postulación</label>
            </div>
            <br>
            <input type="hidden" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <button  onclick="boton1" id="boton1" class="col-lg-4 mt-4 btn btn-primary waves-effect waves-float waves-light">Enviar documentos</button>
        </div>

        <?php else: ?>
        <p class="text-center text-danger">*Llene todos los documentos para poder enviarlos</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>


     document.getElementById('boton1').onclick = function(){


        var query = $('#user_id').val();

        if ($('#confirmo').prop('checked') ) {
// alert(query);
                $.ajax({
                    url:'<?php echo e(route('cambiarestadopos')); ?>',
                    type:'GET',
                    data:{'id_user':query},
                    dataType:'json',
                    success:function (data) {
                        // $('#total_dni').html(data.total_dni);
                        // $('#alerta').html(data);
                        location.href="<?php echo e(route('documentos.docs')); ?>";
                    }
                })
        }else{

            $('#alerta').html('<div class="alert alert-warning" role="alert"><div class="alert-body"><strong>Selecciona el check de confirmacíon</strong></div></div>')
        }


}



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelPostulacion\resources\views/documentos/index.blade.php ENDPATH**/ ?>